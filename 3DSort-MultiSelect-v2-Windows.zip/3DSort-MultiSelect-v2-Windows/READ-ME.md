# 3DSort MultiSelect

## Update: v1.2.3-multiselect.2

Fixes the regional dump cache reverting to pre-injection positions after Verify
or reopening the app. Fresh dumps made after injection are preserved. Import now
refreshes SHA companions even if the dump bytes are identical, clears missing SHA
companions, avoids reusing a previously imported card's container as a fallback,
and refuses a missing or changed pending payload instead of showing an old layout.
Conflicting positions show all affected title names instead of hiding a title;
the warning explains how to refresh the dump and disables Compact.

Close the older app and launch this version. If the old app already loaded stale
positions, run 3DSort_dump on the console once, power off without opening HOME,
and use SYNC → Import layout from SD. This refresh does not require WRITE.

The PC cannot read the console's internal NAND from the SD card alone. After
rearranging on the console, installing/removing NAND titles, or before another
system-layout write after booting HOME, make a fresh GodMode9 dump and import it.
This update fixes reuse of old cached data; it cannot automatically fetch internal
console changes that have not been dumped to the card.

Custom Windows build based on the supplied SalustLab 3DSort v1.2.3 source.
Modified 7 October 2026. Original authors and GPL-3.0 license retained.

## Use

Open `3DSort-MultiSelect.exe` and load your SD card as usual.

1. Click the first game, then hold Shift and click the last game to select a range.
   Ranges follow console cell numbers: down each column, then across to the next.
2. Ctrl-click adds or removes individual titles. Ctrl+Shift-click adds a range.
3. Drag any selected title to move the whole selection in its existing order.
   - Onto another title: insert the selection before it, reordering titles within
     the existing occupied cells. Other types of tiles retain their positions.
   - Onto an empty cell: put selected titles in the available cells starting there,
     skipping occupied or reserved cells. Source cells become empty.
   - Onto a folder: move the selection into its available cells.
   - Inside a folder, onto the return-to-home area: move the selection back home.
4. Escape clears selection (after closing an open dialog or badge panel).

Selected titles have a red outline and check mark. Moving an unselected title
starts a new single selection. Changing folders clears selection. Movable system
apps and NAND titles support selection too; pinned apps, folders and badges do not.
Single-title dragging retains the original swap behavior.

Each group move is one staged change, with one-step Undo/Redo. Insufficient space
rejects the whole move. As in the original, changes reach the card only through
WRITE and its confirmation; automatic backups and inject requirements remain.
Empty-cell and folder moves require the original HOME menu dump setup.

This build uses the original `~/3DSort` settings, work and backup directories.
Close the original app before using this build; do not run both against one card.
Python is not required for the portable executable. The original WebView2 Runtime
requirement still applies.

## Validation and source

Automated tests use synthetic SD data. No physical 3DS or real SD write was tested
for this modification. Source and the GPL license accompany the executable.

Build on Windows with Python 3.10 or newer:

```
python -m pip install -r requirements-dev.txt
python -m pytest tests -q
python -m PyInstaller 3DSort.spec
dist\3DSort-MultiSelect.exe --selftest
```

The build used Python 3.12.14 and PyInstaller 6.22.3. `build-requirements.txt`
records the exact installed Python dependencies. UI tests need Node and Playwright;
set `PYTHON` to the project Python and `CHROMIUM_PATH` to an installed Edge/Chrome.
Run `node tools/test_multiselect_ui.cjs` and `node tools/test_spatial_ui.cjs`.
Set `APP_EXE` to the executable path to test the packaged MultiSelect UI.
